Lackey is a flexible automation framework using image recognition to reliably control complex and non-OS-standard business applications. Potential applications include automating tedious workflows, routine user interface testing, etc. Lackey can also run Sikuli scripts with the help of a shim.


